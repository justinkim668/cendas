# cendas
 Cendas is a new pandas-based framework optimized for analyzing data provided by the U.S. Census Bureau and other U.S. government agencies.
